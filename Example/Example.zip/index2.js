elem.style.color = "red";

var elem = document.getElementById("p_red");

